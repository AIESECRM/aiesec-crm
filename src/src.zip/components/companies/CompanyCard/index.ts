export { default } from './CompanyCard';
